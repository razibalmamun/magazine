<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'bnbd24_hrm');
   define('DB_PASSWORD', '.uDgxy#mYK3^');
   define('DB_DATABASE', 'bnbd24_hrm');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>