<?php $__env->startSection('title', "আমাদের সম্পর্কে"); ?>


<?php $__env->startSection('content'); ?>
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/about_us');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwbnbd24/public_html/resources/views/Pages/About.blade.php ENDPATH**/ ?>