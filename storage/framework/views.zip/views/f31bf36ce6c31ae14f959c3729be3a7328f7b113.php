<html>
    <head>

    </head>
    <body>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<URL>&t=<TITLE>" onclick="javascript:window.open(this.href, 'https://google.com', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Facebook"> Share Facebook </a>
    </body>
</html>
<?php /**PATH /home/wwwbnbd24/public_html/resources/views/Pages/TestPage.blade.php ENDPATH**/ ?>