<?php $__env->startSection('title', "গোপনীয়তার নীতি "); ?>


<?php $__env->startSection('content'); ?>
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/privacy_and_policy');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/breakingnews24bd/public_html/resources/views/Pages/Privacy.blade.php ENDPATH**/ ?>