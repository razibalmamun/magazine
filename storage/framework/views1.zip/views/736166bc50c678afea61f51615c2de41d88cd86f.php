<?php $__env->startSection('title', "যোগাযোগ"); ?>


<?php $__env->startSection('content'); ?>
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/communication');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bnbd24/public_html/resources/views/Pages/CommunicationPage.blade.php ENDPATH**/ ?>